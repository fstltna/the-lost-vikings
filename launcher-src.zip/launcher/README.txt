The Lost Vikings Launcher
Copyright (C) 2014 Blizzard Entertainment

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Only the The Lost Vikings Launcher, based on DOSBox, is licensed under the GNU
General Public License Version 2 ("GPLv2").  See COPYING.txt for the full text
of the license.  For more information about DOSBox, visit:
http://www.dosbox.com/

All title, ownership and intellectual property rights in and to the The Lost Vikings
game, including but not limited to all titles, computer code, themes, objects,
characters, character names, stories, dialogue, catch phrases, locations,
concepts, artwork, structural or landscape designs, animations, sounds, musical
compositions and recordings, audio-visual effects, storylines, character
likenesses, methods of operation, moral rights, and any related documentation
(collectively "Blizzard Property") are owned or licensed by Blizzard
Entertainment, Inc. ("Blizzard"), and are protected by the copyright laws of
the United States, international treaties and conventions, and other applicable
laws.  No Blizzard Property may be licensed or distributed without the express
written authorization of Blizzard.
